// +build !linux

package libnetwork

func setupArrangeUserFilterRule(c *controller) {}
func arrangeUserFilterRule()                   {}
